//MVC - Model
//Grupo Shoegazer - Definição do tipo de peça

    typedef struct 
    {   
        int sideA;
        int sideB;
        bool inGame;
        bool available;
        int player;
    } piece;

    typedef struct{

    }player;

