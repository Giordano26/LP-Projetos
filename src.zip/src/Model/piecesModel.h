//MVC - Model
//Grupo Shoegazer - Definição do tipo de peça

    typedef struct 
    {   
        int sideA;
        int sideB;
    } piece;



